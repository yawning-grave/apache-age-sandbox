using System.Text.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Xunit.Abstractions;

using testdomain;
using testdomain.Annotations;
using testdomain.Internal.GraphSerializer;
using testdomain.Internal.Impl;
using testdomain.Movies;

namespace TestDomains;

public class UnitTest1
{
    private readonly ITestOutputHelper _testOutputHelper;

    public UnitTest1(ITestOutputHelper testOutputHelper)
    {
        _testOutputHelper = testOutputHelper;
    }

    public static JsonSerializerOptions Options = new()
    {
        MaxDepth = 1,
    };
    
    [Fact]
    public void TestTransformMovies()
    {
        var m = ArrangeMovies();
        var s = new ReflectiveTransformer();
        var f = s.Traverse(m.Root);

        foreach (var item in m.Flattened)
        {
            Assert.True(f.Contains(item));
            _testOutputHelper.WriteLine(item.ToString());
        }
    }

    [Fact]
    public void TestSerializeMovie()
    {
        var m = ArrangeMovies();
        var s = new ReflectiveTransformer();
        var f = s.Traverse(m.Root);

        var serialized = new List<(object obj, string ser)>();

        var fmt = Formatting.Indented;
        
        foreach (var specFlattened in m.Flattened)
        {
            var generated = ReflectiveSerializer.Serialize(f.First(item => item.Equals(specFlattened)), fmt);
            
            serialized.Add((specFlattened, generated));
            
            Assert.True(JToken.DeepEquals(
                JToken.Parse(ReflectiveSerializer.Serialize(specFlattened, fmt)), 
                JToken.Parse(generated)));
            
            // _testOutputHelper.WriteLine(specFlattened + "\n" + generated + "\n");
        }

        var groupedAttrs = serialized.GroupBy(tuple => AttributeHelpers.GetAttribute(tuple.obj))
            .ToDictionary(
                g => g.Key!.ToString()!,
                g => g.Select(tuple => tuple.ser).ToList());
        
        foreach (var g in groupedAttrs)
        {
            _testOutputHelper.WriteLine(g.Key);
            foreach (var ser in g.Value)
                _testOutputHelper.WriteLine(ser + "\n");
            _testOutputHelper.WriteLine("");
        }
    }

    static (Movie Root, ISet<object> Flattened) ArrangeMovies()
    {
        var m1 = new Movie { Title = "Inception", Description = "n/a"};
        var m2 = new Movie { Title = "Interstellar", Description = "n/a"};
        var m3 = new Movie { Title = "Good Fellas", Description = "n/a"};
        var m4 = new Movie { Title = "Good Will Hunting", Description = "n/a"};
        
        var p1 = new Person { Name = "Alice", Born = 1964 };
        var p2 = new Person { Name = "Bob", Born = 1976 };
        var p3 = new Person { Name = "Candace", Born = 1999 };
        var p4 = new Person { Name = "Dirk", Born = 2001 };
        var p5 = new Person { Name = "Emma", Born = 1983 };

        var r1 = new Roles { Person = p1, ParticipatedRoles = [ "main cast 'anne'", "extra" ] };
        var r2 = new Roles { Person = p1, ParticipatedRoles = [ "secondary cast 'chatty person at party 13'", "extra" ] };
        var r3 = new Roles { Person = p2, ParticipatedRoles = [ "stunt double" ] };
        var r4 = new Roles { Person = p2, ParticipatedRoles = [ "audience member" ] };
        var r5 = new Roles { Person = p2, ParticipatedRoles = [ "tertiary cast 'background recurrence 25'" ] };
        var r6 = new Roles { Person = p3, ParticipatedRoles = [ "director's staff intern" ] };
        var r7 = new Roles { Person = p3, ParticipatedRoles = [ "tertiary cast 'background recurrence 3'" ] };
        var r8 = new Roles { Person = p4, ParticipatedRoles = [ "high risk stunt double", "tertiary cast 'background recurrence 24'" ] };
        var r9 = new Roles { Person = p5, ParticipatedRoles = [ "primary cast; main actress 'suzanne'" ] };

        m1.Successor = m2;
        m2.Successor = m3;
        m3.Successor = m4;
        
        m1.Directors = [ p1, p2 ];
        m2.Directors = [ p2, p3 ];
        m3.Directors = [ p1, p3 ];
        m4.Directors = [ p5, p1 ];

        m1.Actors = [ r1, r2, r4, r5, r9 ];
        m2.Actors = [ r4, r6, r8, r1, r2 ];
        m3.Actors = [ r1, r7, r3, r2, r5 ];
        m4.Actors = [ r3, r8, r1, r3, r9 ];
        
        return (m1, new HashSet<object>(new IdEqualityComparer<object>())
            { m1, m2, m3, m4, p1, p2, p3, p4, p5, r1, r2, r3, r4, r5, r6, r7, r8, r9 });
    }
}