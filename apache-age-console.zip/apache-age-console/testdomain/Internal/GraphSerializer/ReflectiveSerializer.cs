using System.Reflection;
using Newtonsoft.Json;
using testdomain.Annotations;

namespace testdomain.Internal.GraphSerializer;

public static class ReflectiveSerializer
{
    private const string PATH_SEP = "_";
    private const string META_POSTFIX = "__meta";
    
    // Serialize the object and return a JSON string
    public static string Serialize(object obj, Formatting formatting = Formatting.None)
    {
        var serializedData = new Dictionary<string, object>();
        var visited = new HashSet<object>(ReferenceEqualityComparer.Instance);

        // Start the recursive serialization process
        SerializeObject(obj, "", serializedData, visited);

        // Convert the serialized data dictionary to JSON
        return JsonConvert.SerializeObject(serializedData, formatting);
    }

    private static void SerializeObject(
        object? obj, 
        string path, 
        Dictionary<string, object> serialized,
        HashSet<object> visited)
    {
        if (obj is null || !visited.Add(obj))
            return;
        
        var objType = obj.GetType();
        
        serialized[$"{(path == "" ? "" : path + PATH_SEP)}{META_POSTFIX}"] 
            = new { type = objType.FullName };
        
        var properties = objType
            .GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(prop => prop.GetCustomAttribute<PropertyAttribute>() is not null 
                           || prop.GetCustomAttribute<IdAttribute>() is not null);

        foreach (var prop in properties)
        {
            var fullPath = string.IsNullOrEmpty(path) ? prop.Name : $"{path}{PATH_SEP}{prop.Name}";

            var value = prop.GetValue(obj);
            serialized[fullPath] = value;
            serialized[$"{fullPath}{PATH_SEP}{META_POSTFIX}"] = new { type = prop.PropertyType.FullName };

            // if (IsNode(prop.PropertyType))
                SerializeObject(value, fullPath, serialized, visited);
        }
    }
}