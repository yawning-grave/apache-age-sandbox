using System.Reflection;
using testdomain.Annotations;

namespace testdomain.Internal.Impl;

public class ReflectiveValidator(IEnumerable<Action<Type>> appendableValidators)
{
    public static void EnsureNodeHasId(Type type)
    {
        throw new NotImplementedException();
    }
    
    public static void EnsureTargetNodeReferencesNode(Type type)
    {
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(prop => prop.GetCustomAttribute<TargetNodeAttribute>() is not null);

        foreach (var prop in properties)
        {
            var targetType = prop.PropertyType;

            if (targetType.GetCustomAttribute<NodeAttribute>() == null)
            {
                throw new InvalidOperationException($"property '{prop.Name}' of type '{type.Name}' " +
                                                    $"is marked with [{nameof(TargetNodeAttribute)}], but its type " +
                                                    $"'{targetType.Name}' is not marked with [{nameof(NodeAttribute)}].");
            }
        }
    }

    public static void EnsureRelationshipReferencesNode(Type type)
    {
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(prop => prop.GetCustomAttribute<RelationshipAttribute>() is not null);

        foreach (var prop in properties)
        {
            var targetType = prop.PropertyType;

            if (targetType.GetCustomAttribute<NodeAttribute>() == null)
            {
                throw new InvalidOperationException($"property '{prop.Name}' of type '{type.Name}' " +
                                                    $"is marked with [{nameof(RelationshipAttribute)}], but its type " +
                                                    $"'{targetType.Name}' is not marked with [{nameof(NodeAttribute)}].");
            }
        }
    }
    
    public static void EnsureRelationshipReferencesRelationshipProperties(Type type)
    {
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(prop => prop.GetCustomAttribute<RelationshipAttribute>() is not null);

        foreach (var prop in properties)
        {
            var targetType = prop.PropertyType;

            if (targetType.GetCustomAttribute<RelationshipPropertiesAttribute>() == null)
            {
                throw new InvalidOperationException($"property '{prop.Name}' of type '{type.Name}' " +
                                                    $"is marked with [{nameof(RelationshipAttribute)}], but its type " +
                                                    $"'{targetType.Name}' is not marked with [{nameof(RelationshipPropertiesAttribute)}].");
            }
        }
    }
}