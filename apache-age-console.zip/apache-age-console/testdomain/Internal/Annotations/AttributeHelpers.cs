using System.Reflection;

namespace testdomain.Annotations;

public static class AttributeHelpers
{
    public static bool IsNode(object? obj) 
        => null != obj?.GetType().GetCustomAttribute<NodeAttribute>();
    
    public static bool IsRelationship(object? obj) 
        => null != obj?.GetType().GetCustomAttribute<RelationshipAttribute>();

    public static bool IsRelationshipProperty(object? obj) 
        => null != obj?.GetType().GetCustomAttribute<RelationshipIdAttribute>();

    public static bool IsProperty(object? obj) 
        => null != obj?.GetType().GetCustomAttribute<PropertyAttribute>();
   
    public static bool IsId(object? obj) 
        => null != obj?.GetType().GetCustomAttribute<IdAttribute>();
    
    public static bool IsTargetNode(object? obj) 
        => null != obj?.GetType().GetCustomAttribute<TargetNodeAttribute>();
    
    public static BaseAttribute? GetAttribute(object? obj)
        => obj?.GetType().GetCustomAttribute<BaseAttribute>();
}