namespace testdomain.Annotations;

[AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
public class RelationshipPropertiesAttribute : BaseAttribute
{
    
}