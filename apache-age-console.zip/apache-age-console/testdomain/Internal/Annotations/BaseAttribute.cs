namespace testdomain.Annotations;

public abstract class BaseAttribute : Attribute
{
}