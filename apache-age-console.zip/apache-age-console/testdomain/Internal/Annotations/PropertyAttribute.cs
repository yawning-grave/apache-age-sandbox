namespace testdomain.Annotations;

[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = false)]
public class PropertyAttribute : BaseAttribute
{
    
}