namespace testdomain.Annotations;

[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = false)]
public class RelationshipAttribute(string type, RelationshipAttribute.Direction direction) : BaseAttribute
{
    public enum Direction
    {
        Incoming,
        Outgoing,
    }

    public string Type => type;
    
    public Direction Orientation => direction;
}