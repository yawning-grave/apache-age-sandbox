using System.Reflection;
using Microsoft.VisualBasic;
using testdomain.Annotations;

namespace testdomain.Internal.Impl;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public class ReflectiveTransformer
{
    private HashSet<object> visited = new HashSet<object>(ReferenceEqualityComparer.Instance);

    public ISet<object> Traverse(object startObject)
    {
        var result = new HashSet<object>(new IdEqualityComparer<object>());
        TraverseObject(startObject, result);

        return result;
    }

    private void TraverseObject(object? obj, HashSet<object> result)
    {
        if (obj is not null && visited.Add(obj))
            result.Add(obj);
        else
            return;

        var properties = obj.GetType()
            .GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(prop => prop.GetCustomAttribute<RelationshipAttribute>() is not null 
                           || prop.GetCustomAttribute<RelationshipPropertiesAttribute>() is not null
                           || prop.GetCustomAttribute<NodeAttribute>() is not null
                           || prop.GetCustomAttribute<TargetNodeAttribute>() is not null);

        foreach (var prop in properties)
        {
            if (prop.PropertyType.IsAssignableTo(typeof(System.Collections.IEnumerable))
                && prop.GetValue(obj) as System.Collections.IEnumerable is {} collection)
            {
                foreach (var item in collection)
                    if (item is not null)
                        TraverseObject(item, result);
            }
            else
            {
                if (prop.GetValue(obj) is not {} value)
                    continue;
                
                TraverseObject(value, result);
            }
        }
    }
}
