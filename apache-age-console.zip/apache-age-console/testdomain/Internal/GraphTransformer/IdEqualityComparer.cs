using System.Reflection;
using testdomain.Annotations;

namespace testdomain.Internal.Impl;

public class IdEqualityComparer<T> : IEqualityComparer<T>
{
    public bool Equals(T x, T y)
    {
        if (x == null || y == null)
        {
            return false;
        }

        // Ensure the objects are of the same type
        if (x.GetType() != y.GetType())
        {
            return false;
        }

        // Get the properties marked with the [Id] attribute
        var idProperties = x.GetType()
            .GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.GetCustomAttribute<IdAttribute>() != null)
            .ToList();

        // If no [Id] properties are found, equality can't be checked
        if (idProperties.Count == 0)
        {
            throw new InvalidOperationException("The type does not contain any [Id] properties.");
        }

        // Compare each [Id] property
        foreach (var property in idProperties)
        {
            var valueX = property.GetValue(x);
            var valueY = property.GetValue(y);

            // If any property doesn't match, the objects are not equal
            if (!object.Equals(valueX, valueY))
            {
                return false;
            }
        }

        // All [Id] properties are equal
        return true;
    }

    public int GetHashCode(T obj)
    {
        if (obj == null)
        {
            return 0; // Handle null objects (although in practice, you should avoid nulls in collections)
        }

        // Get the properties marked with the [Id] attribute
        var idProperties = obj.GetType()
            .GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.GetCustomAttribute<IdAttribute>() != null)
            .ToList();

        if (idProperties.Count == 0)
        {
            throw new InvalidOperationException("The type does not contain any [Id] properties.");
        }

        // Combine the hash codes of the [Id] properties (using XOR for uniqueness)
        int hashCode = 0;
        foreach (var property in idProperties)
        {
            var value = property.GetValue(obj);
            if (value != null)
            {
                hashCode ^= value.GetHashCode();
            }
        }

        return hashCode;
    }
}