using System.Reflection;
using testdomain.Annotations;

namespace testdomain.Internal.Impl;

public class AttributeHelper
{
    public static bool IdLike(PropertyInfo property)
    {
        // Check if the property has either IdAttribute or RelationshipIdAttribute
        var isId = property.GetCustomAttribute<IdAttribute>() != null;
        var isRelationshipId = property.GetCustomAttribute<RelationshipIdAttribute>() != null;

        // Both are equivalent in your domain logic
        return isId || isRelationshipId;
    }
}