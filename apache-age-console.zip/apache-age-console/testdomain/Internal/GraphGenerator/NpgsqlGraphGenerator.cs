using System.Data.Common;
using Npgsql;

namespace testdomain.Internal;

public class NpgsqlGraphGenerator(string graph, ISet<object> nodes) : IGraphGenerator
{
    public DbCommand CreateNodes()
    {
        return new NpgsqlCommand("");
    }
}