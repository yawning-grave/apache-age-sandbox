using System.Data.Common;

namespace testdomain.Internal;

public interface IGraphGenerator
{
    DbCommand CreateNodes();
}