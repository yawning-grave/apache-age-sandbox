using testdomain.Annotations;

namespace testdomain.Movies;

[RelationshipProperties]
public class Roles
{
    [Id]
    public long Id { get; set; }
    
    [Property]
    public ICollection<string> ParticipatedRoles { get; set; }
    
    [TargetNode]
    public Person Person { get; set; }
}