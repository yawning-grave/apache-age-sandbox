namespace testdomain.Movies;

public enum Hobbies
{
    Music,
    Literature,
    Food,
    Travel,
}