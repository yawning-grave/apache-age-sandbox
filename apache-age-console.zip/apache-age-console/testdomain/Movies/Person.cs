using testdomain.Annotations;

namespace testdomain.Movies;

[Node]
public class Person
{
    [Id] 
    public string Name { get; set; }

    [Property] 
    public int Born { get; set; }
    
    [Property]
    public Hobbies Hobby { get; set; }
}