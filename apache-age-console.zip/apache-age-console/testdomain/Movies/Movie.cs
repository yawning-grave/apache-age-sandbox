﻿using testdomain.Annotations;
using testdomain.Movies;

namespace testdomain;

[Node]
public class Movie
{
    [Id]
    public string Title { get; set; }
    
    [Property]
    public string Description { get; set; }
    
    [Relationship(type: "ACTED_IN", direction: RelationshipAttribute.Direction.Incoming)]
    public ICollection<Roles> Actors { get; set; } = [];
    
    [Relationship(type: "DIRECTED", direction: RelationshipAttribute.Direction.Incoming)]
    public ICollection<Person> Directors { get; set; } = []; 
    
    [Relationship(type: "SUCCESSOR", direction: RelationshipAttribute.Direction.Incoming)]
    public Movie Successor { get; set; }
}